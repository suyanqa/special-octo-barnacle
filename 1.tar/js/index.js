// 创建一个立即执行的函数来避免全局变量污染
(function() {
    // 页面加载完成后执行
    window.addEventListener('DOMContentLoaded', function() {
        // 判断设备类型并加载对应样式
        if (window.innerWidth <= 767) {
            console.log("用户使用的是移动端设备");
            loadCSS('../css/style.css');
        } else {
            console.log("用户使用的是PC端设备");
            loadCSS('../css/index.css');
        }

        // 初始化菜单点击事件
        initializeMenu();
        
        // 初始化所有导航链接的点击事件
        initializeNavLinks();
    });

    // 加载CSS文件的函数
    function loadCSS(href) {
        let link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = href;
        document.head.appendChild(link);
    }

    // 初始化菜单功能
    function initializeMenu() {
        const menuButton = document.getElementById('menuButton');
        if (menuButton) {
            menuButton.addEventListener('click', toggleMenu);
        }
    }

    // 切换菜单显示状态
    function toggleMenu() {
        const navLinks = document.getElementById('navLinks');
        if (navLinks) {
            navLinks.classList.toggle('active');
        }
    }

    // 初始化导航链接点击事件
    function initializeNavLinks() {
        const navLinks = document.querySelectorAll('#navLinks a');
        navLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const targetId = this.getAttribute('href').slice(1);
                const targetElement = document.getElementById(targetId);
                if (targetElement) {
                    targetElement.scrollIntoView({ behavior: 'smooth' });
                    // 在移动端点击链接后关闭菜单
                    if (window.innerWidth <= 767) {
                        toggleMenu();
                    }
                }
            });
        });
    }
})();

document.addEventListener('DOMContentLoaded', function() {
    const menuToggle = document.getElementById('menuToggle');
    const navLinks = document.getElementById('navLinks');
    
    // 根据屏幕宽度设置初始状态
    function setInitialState() {
        if (window.innerWidth <= 768) {
            menuToggle.style.display = 'block';
            navLinks.style.display = 'none';
        } else {
            menuToggle.style.display = 'none';
            navLinks.style.display = 'flex';
        }
    }
    
    // 初始化状态
    setInitialState();
    
    // 监听窗口大小变化
    window.addEventListener('resize', setInitialState);
    
    // 菜单切换功能
    menuToggle.addEventListener('click', function() {
        if (navLinks.style.display === 'none' || navLinks.style.display === '') {
            navLinks.style.display = 'flex';
            navLinks.style.flexDirection = 'column';
            navLinks.style.position = 'absolute';
            navLinks.style.top = '100%';
            navLinks.style.left = '0';
            navLinks.style.right = '0';
            navLinks.style.backgroundColor = '#fff';
            navLinks.style.padding = '10px';
            navLinks.style.boxShadow = '0 2px 4px rgba(0,0,0,0.1)';
        } else {
            navLinks.style.display = 'none';
        }
    });
    
    // 点击导航链接后关闭菜单
    navLinks.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', function() {
            if (window.innerWidth <= 768) {
                navLinks.style.display = 'none';
            }
        });
    });
});